import dash
import dash_bootstrap_components as dbc
from dash import html, dcc
import dash

app = dash.Dash(__name__, use_pages=True, external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.FONT_AWESOME])

# Layout für die Navigation
app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    dbc.NavbarSimple(
        children=[
            dbc.NavItem(dbc.NavLink("Home", href="/")),
            dbc.NavItem(dbc.NavLink("Customers", href="/customers")),
            dbc.NavItem(dbc.NavLink("Stores", href="/stores")),
            dbc.NavItem(dbc.NavLink("Products", href="/products")),
        ],
        brand="Dashboard",
        brand_href="/",
        color="primary",
        dark=True,
    ),
    dcc.Loading(dash.page_container)
])

if __name__ == '__main__':
    app.run_server(debug=True)
