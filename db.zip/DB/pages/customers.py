import dash
from dash import html, dcc, Input, Output, callback
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd
import psycopg2 as pg

dash.register_page(__name__, name='Customers', path='/customers')

# Verbindungsparameter zur Datenbank
db_host = "localhost"
db_name = "postgres"
db_user = "postgres"
db_password = "password"
db_port = "5432"

# Verbindung zur Datenbank herstellen
connection = pg.connect(
    host=db_host,
    database=db_name,
    user=db_user,
    password=db_password,
    port=db_port
)

cursor = connection.cursor()

def get_customer_data():
    try:
        sql_query = """
                    SELECT c.customerid, c.latitude, c.longitude
                    FROM customers c
                    """
        cursor.execute(sql_query)
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Customer ID", "Latitude", "Longitude"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Kundendaten: {e}")
        return pd.DataFrame()

def get_sales_data(customer_ids, year):
    try:
        sql_query = """
                    SELECT o.customerid, DATE(o.orderdate) as order_date, COUNT(oi.orderid) as sales_count
                    FROM orders o
                    LEFT JOIN orderItems oi ON o.orderid = oi.orderid
                    WHERE o.customerid IN %s AND EXTRACT(YEAR FROM o.orderdate) = %s
                    GROUP BY o.customerid, order_date
                    ORDER BY order_date;
                    """
        cursor.execute(sql_query, (tuple(customer_ids), year))
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Customer ID", "Order Date", "Sales Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Verkaufsdaten: {e}")
        return pd.DataFrame()

customer_data = get_customer_data()

# Dropdown-Optionen für Kunden und Jahre
customer_options = [{'label': f'Customer {customer_id}', 'value': customer_id} for customer_id in
                    customer_data['Customer ID'].unique()]
year_options = [{'label': str(year), 'value': year} for year in range(2020, 2024)]

layout = dbc.Container([
    dbc.Row([
        dbc.Col([html.H3('Customer Locations')], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Dropdown(id='customer-dropdown', options=customer_options, multi=True,
                         placeholder="Select one or more customers")
        ], width=6),
        dbc.Col([
            dcc.Dropdown(id='year-dropdown', options=year_options, placeholder="Select a year")
        ], width=6)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='customer-map')
        ], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='sales-bar-chart')
        ], width=12)
    ])
], className='container')

@callback(
    [Output('customer-map', 'figure'),
     Output('sales-bar-chart', 'figure')],
    [Input('customer-dropdown', 'value'),
     Input('year-dropdown', 'value')]
)
def update_customer_map(selected_customers, selected_year):
    if not selected_customers or not selected_year:
        # Erstelle eine leere Karte und ein leeres Balkendiagramm, wenn keine Kunden oder kein Jahr ausgewählt sind
        fig_map = px.scatter_mapbox(lat=[], lon=[], zoom=3, height=600)
        fig_map.update_layout(mapbox_style="open-street-map")

        fig_bar = px.bar(pd.DataFrame({"Customer ID": [], "Sales Count": []}), x="Customer ID", y="Sales Count")

        return fig_map, fig_bar

    filtered_customer_data = customer_data[customer_data['Customer ID'].isin(selected_customers)]
    sales_data = get_sales_data(selected_customers, selected_year)

    # Erstellen einer Farbkarte für die Kunden
    color_sequence = px.colors.qualitative.Plotly
    color_map = {customer_id: color_sequence[i % len(color_sequence)] for i, customer_id in
                 enumerate(selected_customers)}

    # Aktualisieren der Karte mit den Farben
    fig_map = px.scatter_mapbox(filtered_customer_data, lat="Latitude", lon="Longitude", hover_name="Customer ID",
                                color="Customer ID", color_discrete_map=color_map, zoom=3, height=600)
    fig_map.update_layout(mapbox_style="open-street-map")
    fig_map.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})

    # Balkendiagramm der Verkaufszahlen
    sales_count = sales_data.groupby('Customer ID')['Sales Count'].sum().reset_index()
    fig_bar = px.bar(sales_count, x='Customer ID', y='Sales Count', title='Number of Purchases per Customer',
                     color='Customer ID', color_discrete_map=color_map)

    return fig_map, fig_bar
