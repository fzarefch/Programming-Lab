import dash
from dash import html, dcc, callback, Input, Output, State, callback_context
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objs as go
import pandas as pd
import psycopg2 as pg
from geopy.distance import geodesic

dash.register_page(__name__, name='Stores', path='/stores')

# Verbindungsparameter
db_host = "localhost"
db_name = "postgres"
db_user = "postgres"
db_password = "password"
db_port = "5432"

# Verbindung zur Datenbank herstellen
connection = pg.connect(
    host=db_host,
    database=db_name,
    user=db_user,
    password=db_password,
    port=db_port
)

cursor = connection.cursor()


def get_store_data():
    try:
        sql_query = """
                    SELECT s.storeid, s.latitude, s.longitude, s.city, COUNT(o.orderid) as order_count, COUNT(DISTINCT o.customerid) as customer_count
                    FROM stores s
                    LEFT JOIN orders o ON s.storeid = o.storeid
                    GROUP BY s.storeid, s.latitude, s.longitude, s.city;
                    """
        cursor.execute(sql_query)
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Store ID", "Latitude", "Longitude", "City", "Order Count", "Customer Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Store-Daten: {e}")
        return pd.DataFrame()


def get_sales_data(store_ids, start_date, end_date):
    try:
        sql_query = """
                    SELECT o.storeid, s.city, DATE(o.orderdate) as order_date, COUNT(oi.orderid) as sales_count, 
                    COUNT(DISTINCT o.customerid) as customer_count, SUM(p.price) as total_revenue
                    FROM orders o
                    LEFT JOIN orderItems oi ON o.orderid = oi.orderid
                    LEFT JOIN products p ON oi.sku = p.sku
                    LEFT JOIN stores s ON o.storeid = s.storeid
                    WHERE o.storeid IN %s AND DATE(o.orderdate) BETWEEN %s AND %s
                    GROUP BY o.storeid, s.city, order_date
                    ORDER BY order_date;
                    """
        cursor.execute(sql_query, (tuple(store_ids), start_date, end_date))
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Store ID", "City", "Order Date", "Sales Count", "Customer Count", "Total Revenue"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Verkaufsdaten: {e}")
        return pd.DataFrame()


def get_top_pizzas(store_ids, start_date, end_date):
    try:
        sql_query = """
                    SELECT p.name, COUNT(oi.orderid) as sales_count
                    FROM orders o
                    LEFT JOIN orderItems oi ON o.orderid = oi.orderid
                    LEFT JOIN products p ON oi.sku = p.sku
                    WHERE o.storeid IN %s AND DATE(o.orderdate) BETWEEN %s AND %s
                    GROUP BY p.name
                    ORDER BY sales_count DESC;
                    """
        cursor.execute(sql_query, (tuple(store_ids), start_date, end_date))
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Pizza Name", "Sales Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Pizza-Daten: {e}")
        return pd.DataFrame()


def get_customer_data():
    try:
        sql_query = """
                    SELECT customerid, latitude, longitude
                    FROM customers
                    """
        cursor.execute(sql_query)
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Customer ID", "Latitude", "Longitude"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Kundendaten: {e}")
        return pd.DataFrame()


store_data = get_store_data()
customer_data = get_customer_data()

# Dropdown-Optionen für Stores
city_options = [{'label': city, 'value': city} for city in store_data['City'].unique()]

layout = dbc.Container([
    dbc.Row([
        dbc.Col([html.H3('Store Locations')], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.DatePickerRange(
                id='date-picker-range',
                start_date=pd.to_datetime('2022-01-01'),
                end_date=pd.to_datetime('2022-12-31'),
                display_format='YYYY-MM-DD'
            )
        ], width=6),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='store-map')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Dropdown(id='city-dropdown', options=city_options, multi=True,
                         placeholder="Wählen Sie eine oder mehrere Städte")
        ], width=6),
    ]),
    dbc.Row([
        dbc.Col([
            html.Div(id='store-sales-info', style={'font-size': '20px', 'margin-top': '20px'})
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='sales-bar-chart-orders')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='sales-bar-chart-customers')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='top-pizzas-bar-chart')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            html.Div(id='customer-proximity-info', style={'font-size': '20px', 'margin-top': '20px'})
        ], width=12),
    ]),
], className='container')


@callback(
    Output('store-map', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date')
)
def update_store_map(start_date, end_date):
    # Store map
    map_fig = px.scatter_mapbox(store_data, lat="Latitude", lon="Longitude", hover_name="Store ID",
                                size="Order Count", color="Order Count",
                                color_continuous_scale=px.colors.sequential.Viridis, zoom=3, height=300)
    map_fig.update_layout(mapbox_style="open-street-map")
    map_fig.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})

    return map_fig


@callback(
    [Output('city-dropdown', 'value'),
     Output('sales-bar-chart-orders', 'figure'),
     Output('sales-bar-chart-customers', 'figure'),
     Output('store-sales-info', 'children'),
     Output('top-pizzas-bar-chart', 'figure'),
     Output('customer-proximity-info', 'children')],
    [Input('store-map', 'clickData'),
     Input('date-picker-range', 'start_date'),
     Input('date-picker-range', 'end_date'),
     Input('city-dropdown', 'value'),
     Input('sales-bar-chart-orders', 'relayoutData'),
     Input('sales-bar-chart-customers', 'relayoutData')]
)
def update_store_sales(map_click, start_date, end_date, selected_cities, relayout_orders, relayout_customers):
    ctx = callback_context
    triggered = ctx.triggered[0]['prop_id']

    zoom_in_orders = 'xaxis.range[0]' in (relayout_orders or {})
    zoom_in_customers = 'xaxis.range[0]' in (relayout_customers or {})
    zoom_in = zoom_in_orders or zoom_in_customers

    if triggered == 'store-map.clickData':
        selected_store = map_click['points'][0]['hovertext']
        selected_city = store_data[store_data['Store ID'] == selected_store]['City'].values[0]
        if selected_cities is None:
            selected_cities = [selected_city]
        elif selected_city not in selected_cities:
            selected_cities.append(selected_city)

    if selected_cities is None or not selected_cities:
        filtered_store_data = store_data
    else:
        filtered_store_data = store_data[store_data['City'].isin(selected_cities)]

    store_ids = filtered_store_data['Store ID'].tolist()

    # Fetch sales data for the selected date range
    sales_data = get_sales_data(store_ids, start_date, end_date)
    top_pizzas_data = get_top_pizzas(store_ids, start_date, end_date)

    # Aggregate sales data by store
    store_sales_info = sales_data.groupby(['Store ID', 'City']).agg(
        total_orders=pd.NamedAgg(column='Sales Count', aggfunc='sum'),
        total_customers=pd.NamedAgg(column='Customer Count', aggfunc='sum'),
        total_revenue=pd.NamedAgg(column='Total Revenue', aggfunc='sum')
    ).reset_index()

    sales_info_text = []
    for _, row in store_sales_info.iterrows():
        sales_info_text.append(html.P(
            f"Store {row['Store ID']} in {row['City']}: Total Orders = {row['total_orders']}, "
            f"Total Customers = {row['total_customers']}, Total Revenue = €{row['total_revenue']:,.2f}"))

    if zoom_in:
        sales_data['Day'] = pd.to_datetime(sales_data['Order Date']).dt.to_period('D')
        sales_by_period_orders = sales_data.groupby(['Day', 'City'])['Sales Count'].sum().reset_index()
        sales_by_period_customers = sales_data.groupby(['Day', 'City'])['Customer Count'].sum().reset_index()
        sales_by_period_orders['Day'] = sales_by_period_orders['Day'].astype(str)
        sales_by_period_customers['Day'] = sales_by_period_customers['Day'].astype(str)
        bar_fig_orders = px.bar(sales_by_period_orders, x='Day', y='Sales Count', color='City', title='Number of Orders Over Time', barmode='group')
        bar_fig_customers = px.bar(sales_by_period_customers, x='Day', y='Customer Count', color='City', title='Number of Customers Over Time', barmode='group')
    else:
        sales_data['Month'] = pd.to_datetime(sales_data['Order Date']).dt.to_period('M')
        sales_by_month_orders = sales_data.groupby(['Month', 'City'])['Sales Count'].sum().reset_index()
        sales_by_month_customers = sales_data.groupby(['Month', 'City'])['Customer Count'].sum().reset_index()
        sales_by_month_orders['Month'] = sales_by_month_orders['Month'].astype(str)
        sales_by_month_customers['Month'] = sales_by_month_customers['Month'].astype(str)
        bar_fig_orders = px.bar(sales_by_month_orders, x='Month', y='Sales Count', color='City', title='Number of Orders Over Time', barmode='group')
        bar_fig_customers = px.bar(sales_by_month_customers, x='Month', y='Customer Count', color='City', title='Number of Customers Over Time', barmode='group')

    bar_fig_orders.update_layout(xaxis={'type': 'category'})
    bar_fig_customers.update_layout(xaxis={'type': 'category'})

    top_pizzas_bar = px.bar(top_pizzas_data, x='Pizza Name', y='Sales Count', title='Top Selling Pizzas')

    # Calculate customer proximity
    proximity_info = []
    for store_id, store_lat, store_lon in zip(filtered_store_data['Store ID'], filtered_store_data['Latitude'], filtered_store_data['Longitude']):
        store_location = (store_lat, store_lon)
        customer_locations = customer_data[['Latitude', 'Longitude']].apply(tuple, axis=1)
        customers_within_1_mile = sum(geodesic(store_location, customer_location).miles <= 1 for customer_location in customer_locations)
        customers_within_10_miles = sum(geodesic(store_location, customer_location).miles <= 10 for customer_location in customer_locations)
        total_customers = len(customer_data)
        proximity_info.append(html.P(
            f"Store {store_id}: {customers_within_1_mile / total_customers * 100:.2f}% of customers live within 1 mile, "
            f"{customers_within_10_miles / total_customers * 100:.2f}% within 10 miles."
        ))

    return selected_cities, bar_fig_orders, bar_fig_customers, sales_info_text, top_pizzas_bar, proximity_info
