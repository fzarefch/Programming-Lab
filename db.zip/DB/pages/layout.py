# layout.py
import dash_bootstrap_components as dbc
from dash import html, dcc

def create_layout(get_product_options, get_year_options):
    layout = dbc.Container([
        dbc.Row([
            dbc.Col([html.H3('Product Performance')], width=12, className='h3')
        ], className='row-margin'),
        dbc.Row([
            dbc.Col([
                dcc.Dropdown(id='product-dropdown', options=get_product_options(), multi=True,
                             placeholder="Wählen Sie ein oder mehrere Produkte")
            ], width=6),
            dbc.Col([
                dcc.Dropdown(id='year-dropdown', options=get_year_options(), placeholder="Wählen Sie ein Jahr")
            ], width=6)
        ], className='row-margin'),
        dbc.Row([
            dbc.Col([html.Div(id='total_pizzas', style={'font-size': '20px', 'margin-top': '20px'})], width=6, className='col-background'),
            dbc.Col([html.Div(id='total_revenue', style={'font-size': '20px', 'margin-top': '20px'})], width=6, className='col-background')
        ], className='row-margin'),
        dbc.Row([
            dbc.Col([
                dcc.Graph(id='revenue_by_type')
            ], width=12),
        ], className='graph-background'),
        dbc.Row([
            dbc.Col([
                dcc.Graph(id='sales_over_time')
            ], width=12),
        ], className='graph-background'),
        dbc.Row([
            dbc.Col([
                dcc.Graph(id='sales_by_hour')
            ], width=12),
        ], className='graph-background'),
        # Speichern Sie den gemeinsamen Zustand der Achsenbereiche
        dcc.Store(id='shared-axes')
    ])
    return layout
