import dash
from dash import html, dcc, callback, Input, Output, State, callback_context
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd
import psycopg2 as pg

dash.register_page(__name__, name='Products', path='/products')

# Verbindung zur Datenbank herstellen
db_host = "localhost"
db_name = "postgres"
db_user = "postgres"
db_password = "password"
db_port = "5432"

connection = pg.connect(
    host=db_host,
    database=db_name,
    user=db_user,
    password=db_password,
    port=db_port
)

cursor = connection.cursor()


def get_product_performance():
    try:
        sql_query = """
                    SELECT p.name, p.sku, p.size, p.launch as launch_date, MAX(o.orderdate) as last_order_date, COUNT(oi.orderid) as sales_count
                    FROM products p
                    LEFT JOIN orderItems oi ON p.sku = oi.sku
                    LEFT JOIN orders o ON oi.orderid = o.orderid
                    GROUP BY p.name, p.sku, p.size, p.launch
                    ORDER BY sales_count DESC;
                    """
        cursor.execute(sql_query)
        results = cursor.fetchall()
        return pd.DataFrame(results,
                            columns=["Product Name", "SKU", "Size", "Launch Date", "Last Order Date", "Sales Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Produktperformance: {e}")
        return pd.DataFrame()


product_performance = get_product_performance()


def get_product_options():
    return [{'label': f"{name} ({size})", 'value': sku} for name, sku, size in
            zip(product_performance['Product Name'], product_performance['SKU'], product_performance['Size'])]


def get_year_options():
    years = pd.DatetimeIndex(product_performance['Launch Date']).year.unique()
    return [{"label": str(year), "value": year} for year in years]


# Farbzuordnung
color_discrete_map = {name: px.colors.qualitative.Bold[i % len(px.colors.qualitative.Bold)] for i, name in
                      enumerate(product_performance['Product Name'].unique())}


def get_sales_data(selected_skus, selected_year):
    try:
        sku_placeholder = ', '.join(['%s'] * len(selected_skus))
        sql_query = f"""
                    SELECT EXTRACT(MONTH FROM o.orderdate) as Month, p.name, COUNT(oi.orderid) as Sales_Count
                    FROM orders o
                    LEFT JOIN orderItems oi ON o.orderid = oi.orderid
                    LEFT JOIN products p ON oi.sku = p.sku
                    WHERE oi.sku IN ({sku_placeholder}) AND EXTRACT(YEAR FROM o.orderdate) = %s
                    GROUP BY EXTRACT(MONTH FROM o.orderdate), p.name
                    ORDER BY EXTRACT(MONTH FROM o.orderdate);
                    """
        cursor.execute(sql_query, tuple(selected_skus) + (selected_year,))
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Month", "Product Name", "Sales_Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Verkaufsdaten: {e}")
        return pd.DataFrame()


def get_sales_by_day(selected_skus, selected_year, selected_month):
    try:
        sku_placeholder = ', '.join(['%s'] * len(selected_skus))
        sql_query = f"""
                    SELECT EXTRACT(DAY FROM o.orderdate) as Day, p.name, COUNT(oi.orderid) as Sales_Count
                    FROM orders o
                    LEFT JOIN orderItems oi ON o.orderid = oi.orderid
                    LEFT JOIN products p ON oi.sku = p.sku
                    WHERE oi.sku IN ({sku_placeholder}) AND EXTRACT(YEAR FROM o.orderdate) = %s AND EXTRACT(MONTH FROM o.orderdate) = %s
                    GROUP BY EXTRACT(DAY FROM o.orderdate), p.name
                    ORDER BY EXTRACT(DAY FROM o.orderdate);
                    """
        cursor.execute(sql_query, tuple(selected_skus) + (selected_year, selected_month))
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Day", "Product Name", "Sales_Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Verkaufsdaten nach Tag: {e}")
        return pd.DataFrame()


def get_sales_by_hour(selected_skus, selected_year):
    try:
        sku_placeholder = ', '.join(['%s'] * len(selected_skus))
        sql_query = f"""
                    SELECT EXTRACT(HOUR FROM o.orderdate) as Hour, p.name, COUNT(oi.orderid) as Sales_Count
                    FROM orders o
                    LEFT JOIN orderItems oi ON o.orderid = oi.orderid
                    LEFT JOIN products p ON oi.sku = p.sku
                    WHERE oi.sku IN ({sku_placeholder}) AND EXTRACT(YEAR FROM o.orderdate) = %s
                    GROUP BY EXTRACT(HOUR FROM o.orderdate), p.name
                    ORDER BY EXTRACT(HOUR FROM o.orderdate);
                    """
        cursor.execute(sql_query, tuple(selected_skus) + (selected_year,))
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Hour", "Product Name", "Sales_Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Verkaufsdaten nach Uhrzeit: {e}")
        return pd.DataFrame()


layout = dbc.Container([
    dbc.Row([
        dbc.Col([html.H3('Product Performance')], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Dropdown(id='product-dropdown', options=get_product_options(), multi=True,
                         placeholder="Wählen Sie ein oder mehrere Produkte")
        ], width=6),
        dbc.Col([
            dcc.Dropdown(id='year-dropdown', options=get_year_options(), placeholder="Wählen Sie ein Jahr")
        ], width=6)
    ]),
    dbc.Row([
        dbc.Col([html.Div(id='total_pizzas')], width=6),
        dbc.Col([html.Div(id='total_revenue')], width=6)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='revenue_by_type')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='sales_over_time')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='sales_by_hour')
        ], width=12),
    ]),
    dcc.Store(id='shared-axes'),
    dcc.Store(id='clicked-month', storage_type='memory')
], className='container')


@dash.callback(
    Output('shared-axes', 'data'),
    Output('clicked-month', 'data'),
    [Input('revenue_by_type', 'relayoutData'),
     Input('sales_over_time', 'relayoutData'),
     Input('sales_by_hour', 'relayoutData'),
     Input('revenue_by_type', 'clickData')],
    [State('shared-axes', 'data'),
     State('clicked-month', 'data')]
)
def update_axes(revenue_relayout, sales_time_relayout, sales_hour_relayout, revenue_click, shared_axes, clicked_month):
    ctx = callback_context
    if not ctx.triggered:
        return shared_axes, clicked_month

    input_id = ctx.triggered[0]['prop_id'].split('.')[0]

    if shared_axes is None:
        shared_axes = {}

    if input_id == 'revenue_by_type' and revenue_relayout:
        shared_axes['revenue_by_type'] = revenue_relayout
    elif input_id == 'sales_over_time' and sales_time_relayout:
        shared_axes['sales_over_time'] = sales_time_relayout
    elif input_id == 'sales_by_hour' and sales_hour_relayout:
        shared_axes['sales_by_hour'] = sales_hour_relayout

    # Handle click data
    if input_id == 'revenue_by_type' and revenue_click:
        clicked_month = {'Month': revenue_click['points'][0]['x']}

    return shared_axes, clicked_month


@dash.callback(
    [Output('total_pizzas', 'children'),
     Output('total_revenue', 'children'),
     Output('revenue_by_type', 'figure'),
     Output('sales_over_time', 'figure'),
     Output('sales_by_hour', 'figure')],
    [Input('product-dropdown', 'value'),
     Input('year-dropdown', 'value'),
     Input('shared-axes', 'data'),
     Input('clicked-month', 'data')]
)
def update_dashboard(selected_skus, selected_year, shared_axes, clicked_month):
    if selected_skus is None or selected_year is None:
        return "Bitte wählen Sie ein oder mehrere Produkte und ein Jahr", "", {}, {}, {}
    sales_data = get_sales_data(selected_skus, selected_year)
    sales_by_hour = get_sales_by_hour(selected_skus, selected_year)

    total_pizzas = sales_data['Sales_Count'].sum()
    total_revenue = total_pizzas * 10  # Annahme: jede Pizza kostet 10 Euro

    revenue_by_type = px.bar(
        sales_data,
        x='Month',
        y='Sales_Count',
        color='Product Name',
        color_discrete_map=color_discrete_map,
        barmode='group',
        labels={'Month': 'Month', 'Sales_Count': 'Sales Count'}
    )

    sales_over_time = px.line(
        sales_data,
        x='Month',
        y='Sales_Count',
        color='Product Name',
        line_group='Product Name',
        color_discrete_map=color_discrete_map,
        labels={'Month': 'Month', 'Sales_Count': 'Sales Count'}
    )

    sales_by_hour_fig = px.bar(
        sales_by_hour,
        x='Hour',
        y='Sales_Count',
        color='Product Name',
        color_discrete_map=color_discrete_map,
        title='Sales by Hour',
        labels={'Hour': 'Hour of the Day', 'Sales_Count': 'Sales Count'}
    )

    # Update axis ranges based on shared_axes
    if shared_axes:
        if 'revenue_by_type' in shared_axes:
            revenue_by_type.update_layout(xaxis=shared_axes['revenue_by_type'].get('xaxis', {}),
                                          yaxis=shared_axes['revenue_by_type'].get('yaxis', {}))
        if 'sales_over_time' in shared_axes:
            sales_over_time.update_layout(xaxis=shared_axes['sales_over_time'].get('xaxis', {}),
                                          yaxis=shared_axes['sales_over_time'].get('yaxis', {}))
        if 'sales_by_hour' in shared_axes:
            sales_by_hour_fig.update_layout(xaxis=shared_axes['sales_by_hour'].get('xaxis', {}),
                                            yaxis=shared_axes['sales_by_hour'].get('yaxis', {}))

    # Apply zoom based on clicked month
    if clicked_month:
        month = clicked_month['Month']
        sales_by_day_data = get_sales_by_day(selected_skus, selected_year, month)
        sales_over_time = px.line(
            sales_by_day_data,
            x='Day',
            y='Sales_Count',
            color='Product Name',
            line_group='Product Name',
            color_discrete_map=color_discrete_map,
            labels={'Day': 'Day', 'Sales_Count': 'Sales Count'},
            title=f'Sales in Month {month}'
        )

    # Highlight the selected bars
    if clicked_month:
        selected_month = clicked_month['Month']
        for trace in revenue_by_type.data:
            mask = (sales_data['Month'] == selected_month) & (sales_data['Product Name'] == trace.name)
            trace.marker.line.width = [2 if m else 0 for m in mask]
            trace.marker.line.color = 'black'

    return f"{total_pizzas:,}", f"${total_revenue:,.2f}", revenue_by_type, sales_over_time, sales_by_hour_fig


