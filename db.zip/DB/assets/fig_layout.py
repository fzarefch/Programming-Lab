import plotly.graph_objects as go

# Layout Einstellungen für das Diagramm
font_style = {
    'color': '#f6f6f6'
}

margin_style = {
    'b': 10,
    'l': 50,
    'r': 8,
    't': 50,
    'pad': 0
}

xaxis_style = {
    'linewidth': 1,
    'linecolor': 'rgba(0, 0, 0, 0.35%)',
    'showgrid': False,
    'zeroline': False
}

yaxis_style = {
    'linewidth': 1,
    'linecolor': 'rgba(0, 0, 0, 0.35%)',
    'showgrid': True,
    'gridwidth': 1,
    'gridcolor': 'rgba(0, 0, 0, 0.11%)',
    'zeroline': False
}

my_figlayout = go.Layout(
    paper_bgcolor='rgba(255,0,0,0)',  # Hintergrund des gesamten Plots (außerhalb des eigentlichen Plots)
    plot_bgcolor='#1f2c56',  # Hintergrund des eigentlichen Plots
    font=font_style,
    margin=margin_style,
    xaxis=xaxis_style,
    yaxis=yaxis_style,
    height=300
)

# Traces Layout Einstellungen
my_linelayout = {
    'width': 3,
    'color': '#3DED97'
}

fig = go.Figure(layout=my_figlayout)
fig.add_trace(go.Scatter(
    x=[1, 2, 3],
    y=[4, 5, 6],
    mode='lines',
    line=my_linelayout
))

fig.show()
