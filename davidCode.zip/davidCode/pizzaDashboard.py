import psycopg2 as pg
from dash import dcc, html, Dash
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import pytz
from dash.exceptions import PreventUpdate

# Verbindungsparameter
db_host = "localhost"
db_name = "pizzeria"
db_user = "postgres"
db_password = "password"
db_port = "5432"

# Verbindung zur Datenbank herstellen
connection = pg.connect(host=db_host, database=db_name, user=db_user, password=db_password, port=db_port,
                        client_encoding='utf-8')
cursor = connection.cursor()

berlin_tz = pytz.timezone('Europe/Berlin')


def get_order_date_range(cursor):
    """Fetches the minimum and maximum order dates from the 'Orders' table."""
    try:
        sql_query = """
                    SELECT MIN("orderdate"::timestamp - INTERVAL '9 hours') as min_date, 
                           MAX("orderdate"::timestamp - INTERVAL '9 hours') as max_date
                    FROM orders;
                    """
        cursor.execute(sql_query)
        result = cursor.fetchone()
        return result[0], result[1]
    except Exception as e:
        print(f"Fehler beim Abrufen des Datumsbereichs: {e}")
        connection.rollback()
        return None, None


def fetch_orders(cursor, start_date, end_date):
    """Fetches orders from the 'Orders' table within a specified date range."""
    try:
        sql_query = f"""
                    SELECT "orderid", "orderdate"::timestamp - INTERVAL '9 hours' as "orderdate"
                    FROM orders
                    WHERE "orderdate" >= '{start_date}' AND "orderdate" <= '{end_date}';
                    """
        cursor.execute(sql_query)
        result = cursor.fetchall()
        df = pd.DataFrame(result, columns=["orderid", "orderdate"])
        df["orderdate"] = pd.to_datetime(df["orderdate"], errors='coerce')
        return df
    except Exception as e:
        print(f"Fehler beim Abrufen der Bestellungen: {e}")
        connection.rollback()
        return pd.DataFrame()




def get_store_data(cursor, year):
    """Fetches store data including locations and number of orders from the 'Stores' and 'Orders' tables."""
    if year is None:
        year = pd.Timestamp.now().year  # Fallback auf das aktuelle Jahr

    try:
        sql_query = f"""
                    SELECT s."latitude", s."longitude", s."city", COUNT(o."orderid") as order_count
                    FROM stores s
                    LEFT JOIN orders o ON s."storeid" = o."storeid" AND EXTRACT(YEAR FROM o."orderdate"::date) = {year}
                    GROUP BY s."latitude", s."longitude", s."city";
                    """
        cursor.execute(sql_query)
        results = cursor.fetchall()
        store_data = pd.DataFrame(results, columns=["lat", "lon", "City", "Order Count"])
        store_data["Order Count"] = pd.to_numeric(store_data["Order Count"], errors='coerce').fillna(0)
        store_data = store_data.dropna(subset=["lat", "lon", "Order Count"])
        return store_data
    except Exception as e:
        print(f"Fehler beim Abrufen von Daten der Stores: {e}")
        connection.rollback()
        return pd.DataFrame()



# Funktion zur Erstellung des Dropdown-Menüs für Jahre
def create_year_dropdown():
    current_year = pd.Timestamp.now().year
    years = list(range(2020, 2023))  # Annahme: Daten sind von 2020 bis zum aktuellen Jahr verfügbar
    dropdown_options = [{"label": str(year), "value": year} for year in years]
    dropdown = dcc.Dropdown(
        id='year-dropdown',
        options=dropdown_options,
        value=current_year  # Standardwert auf das aktuelle Jahr setzen
    )
    return dropdown


# Minimal- und Maximaldatum aus der Datenbank abrufen
min_date, max_date = get_order_date_range(cursor)

# Dash-App initialisieren
app = Dash(__name__, assets_folder='assets')

# Layout des Dashboards definieren
app.layout = html.Div([
    dcc.Store(id='dark-mode-store', data={'dark_mode': False}),
    html.Div(id='dummy-div', style={'display': 'none'}),
    html.Div([
        html.H1("Pizzeria Dashboard"),
        html.Button("Toggle Dark Mode", id="btn-toggle-dark-mode", n_clicks=0)
    ], className='banner'),
    html.Div(className='container', children=[
        html.Div(className='analysis-container', children=[
            html.Div(className='h2-container', children=[
                html.H2("Order Dates")
            ]),
            dcc.Graph(id='order-time-graph'),
            html.Label("Choose a period:"),
            html.Div(className='datePicker', children=[
                dcc.DatePickerRange(
                    id='date-picker-range',
                    start_date=min_date,
                    end_date=max_date,
                    display_format='YYYY-MM-DD',
                    persistence=True,
                    persistence_type='session'
                )
            ]),
        ]),
        html.Div(className='analysis-container', children=[
            html.Div(className='h2-container', children=[
                html.H2("Location Analysis")
            ]),
            create_year_dropdown(),  # Dropdown-Menü für Jahre hinzufügen
            html.Div(className='analysis-box', children=[
                dcc.Graph(id='choropleth-map')  # Choroplethenkarte hinzufügen
            ]),
            html.Div(className='analysis-box', children=[
                dcc.Graph(id='bar-chart')  # Balkendiagramm hinzufügen
            ])
        ]),
    ])
])


# Callback-Funktion für die Aktualisierung der Bestellzeitpunkte-Grafik basierend auf dem ausgewählten Zeitraum
@app.callback(
    Output('order-time-graph', 'figure'),
    [Input('date-picker-range', 'start_date'),
     Input('date-picker-range', 'end_date')]
)
def update_graph(start_date, end_date):
    df = fetch_orders(cursor, start_date, end_date)
    if df.empty:
        return px.bar()  # Leeres Diagramm zurückgeben, wenn keine Daten vorhanden sind

    order_counts = df.groupby(df['orderdate'].dt.hour).size().reset_index(name='count')
    fig = px.bar(order_counts, x='orderdate', y='count',
                 labels={'orderdate': 'Hour', 'count': 'Number of orders'})
    fig.update_layout(title='Orders per hour',
                      xaxis_title='Time',
                      yaxis_title='Number of orders')
    return fig



# Callback-Funktion für die Aktualisierung der Choroplethenkarte und des Balkendiagramms basierend auf dem ausgewählten Jahr
@app.callback(
    [Output('choropleth-map', 'figure'),
     Output('bar-chart', 'figure')],
    [Input('year-dropdown', 'value')]
)
def update_maps_and_chart(selected_year):
    store_data = get_store_data(cursor, selected_year)
    top_stores = store_data.nlargest(3, "Order Count").reset_index(drop=True)
    predefined_colors = ['#EF553B', '#EF553B', '#EF553B']  # Rot für die Top 3 Städte
    top_stores['Color'] = predefined_colors
    color_map = {city: color for city, color in zip(top_stores["City"], predefined_colors)}
    store_data['Color'] = store_data['City'].map(color_map).fillna('#838b8b')

    fig = px.scatter_mapbox(store_data, lat="lat", lon="lon", hover_name="City", size="Order Count",
                            color='City', color_discrete_map=color_map,
                            zoom=4, height=300, width=440)
    fig.update_layout(mapbox_style="open-street-map")
    fig.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})

    for trace in fig.data:
        if trace.name not in top_stores['City'].values:
            trace.showlegend = False
            trace.marker.color = '#838b8b'  # Graue Farbe für andere Städte


    bar_fig = px.bar(top_stores, x="City", y="Order Count", color="City",
                     color_discrete_map=color_map,
                     labels={"Order Count": "Number of orders", "City": "City"},
                     title="Top 3 stores with most sold products")

    return fig, bar_fig


@app.callback(
    Output('dark-mode-store', 'data'),
    Input('btn-toggle-dark-mode', 'n_clicks')
)
def toggle_dark_mode(n_clicks):
    dark_mode = n_clicks % 2 == 1
    return {'dark_mode': dark_mode}


@app.callback(
    Output('btn-toggle-dark-mode', 'children'),
    Input('dark-mode-store', 'data')
)
def update_button_text(data):
    return "Turn to Light Mode" if data['dark_mode'] else "Turn to Dark Mode"


app.clientside_callback(
    """
    function(data) {
        if (data.dark_mode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
        return '';
    }
    """,
    Output('dummy-div', 'children'),
    Input('dark-mode-store', 'data')
)

if __name__ == '__main__':
    app.run_server(debug=True)

cursor.close()
connection.close()
