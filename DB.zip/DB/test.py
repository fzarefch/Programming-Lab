import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

fig, ax = plt.subplots(figsize=(12, 8))

# Mandant
ax.text(0.5, 1, 'Mandant (Client)\nGBI Global (800)', horizontalalignment='center', fontsize=14, bbox=dict(facecolor='lightgray', edgecolor='black'))

# Buchungskreis
ax.text(0.25, 0.8, 'Buchungskreis (Company Code)\nUS00 (USA)', horizontalalignment='center', fontsize=12, bbox=dict(facecolor='lightblue', edgecolor='black'))
ax.text(0.75, 0.8, 'Buchungskreis (Company Code)\nDE00 (Deutschland)', horizontalalignment='center', fontsize=12, bbox=dict(facecolor='lightblue', edgecolor='black'))

# Werke
ax.text(0.125, 0.6, 'Werk (Plant)\nDallas (DL00)', horizontalalignment='center', fontsize=10, bbox=dict(facecolor='lightgreen', edgecolor='black'))
ax.text(0.375, 0.6, 'Werk (Plant)\nMiami (MI00)', horizontalalignment='center', fontsize=10, bbox=dict(facecolor='lightgreen', edgecolor='black'))
ax.text(0.625, 0.6, 'Werk (Plant)\nHeidelberg (HD00)', horizontalalignment='center', fontsize=10, bbox=dict(facecolor='lightgreen', edgecolor='black'))
ax.text(0.875, 0.6, 'Werk (Plant)\nHamburg (HB00)', horizontalalignment='center', fontsize=10, bbox=dict(facecolor='lightgreen', edgecolor='black'))

# Lagerorte
ax.text(0.125, 0.4, 'Lagerort (Storage Location)\nFG00, RM00', horizontalalignment='center', fontsize=8, bbox=dict(facecolor='lightyellow', edgecolor='black'))
ax.text(0.375, 0.4, 'Lagerort (Storage Location)\nFG00, RM00', horizontalalignment='center', fontsize=8, bbox=dict(facecolor='lightyellow', edgecolor='black'))
ax.text(0.625, 0.4, 'Lagerort (Storage Location)\nFG00, RM00', horizontalalignment='center', fontsize=8, bbox=dict(facecolor='lightyellow', edgecolor='black'))
ax.text(0.875, 0.4, 'Lagerort (Storage Location)\nFG00, RM00', horizontalalignment='center', fontsize=8, bbox=dict(facecolor='lightyellow', edgecolor='black'))

# Vertriebsbereiche
ax.text(0.5, 0.2, 'Vertriebsbereich (Sales Area)\nUE00/UW00/DE00 - WH/RE - BI/AS', horizontalalignment='center', fontsize=10, bbox=dict(facecolor='lightcoral', edgecolor='black'))

# Connecting lines
connections = [
    ((0.5, 0.97), (0.25, 0.83)),
    ((0.5, 0.97), (0.75, 0.83)),
    ((0.25, 0.77), (0.125, 0.63)),
    ((0.25, 0.77), (0.375, 0.63)),
    ((0.75, 0.77), (0.625, 0.63)),
    ((0.75, 0.77), (0.875, 0.63)),
    ((0.125, 0.57), (0.125, 0.43)),
    ((0.375, 0.57), (0.375, 0.43)),
    ((0.625, 0.57), (0.625, 0.43)),
    ((0.875, 0.57), (0.875, 0.43)),
    ((0.5, 0.37), (0.5, 0.23)),
]

for start, end in connections:
    ax.plot([start[0], end[0]], [start[1], end[1]], 'k-', lw=1)

ax.axis('off')
plt.show()
