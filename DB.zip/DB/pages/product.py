import dash
import psycopg2 as pg
from dash import html, dcc, callback, Input, Output
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd

dash.register_page(__name__, name='Products', path='/products')

# Verbindungsparameter
db_host = "localhost"
db_name = "postgres"
db_user = "postgres"
db_password = "password"
db_port = "5432"

# Verbindung zur Datenbank herstellen
connection = pg.connect(
    host=db_host,
    database=db_name,
    user=db_user,
    password=db_password,
    port=db_port,
    client_encoding='utf-8'
)
cursor = connection.cursor()


def get_product_performance(cursor):
    """Fetches product performance including sales count since launch until the last order."""
    try:
        sql_query = """
                    SELECT p.name, p.sku, p.launch as launch_date, MAX(o.orderdate) as last_order_date, COUNT(oi.orderid) as sales_count
                    FROM products p
                    LEFT JOIN orderItems oi ON p.sku = oi.sku
                    LEFT JOIN orders o ON oi.orderid = o.orderid
                    GROUP BY p.name, p.sku, p.launch
                    ORDER BY sales_count DESC;
                    """
        cursor.execute(sql_query)
        results = cursor.fetchall()
        product_performance = pd.DataFrame(results, columns=["Product Name", "SKU", "Launch Date", "Last Order Date",
                                                             "Sales Count"])

        return product_performance
    except Exception as e:
        print(f"Fehler beim Abrufen der Produktperformance: {e}")
        return pd.DataFrame()

# Daten der Produktperformance abrufen
product_performance = get_product_performance(cursor)

# Jahre auswählen
years = pd.DatetimeIndex(product_performance['Launch Date']).year.unique()

# Dropdown-Menü für Produkt
product_dropdown = dcc.Dropdown(
    id='product-dropdown',
    options=[{'label': name, 'value': sku} for name, sku in
             zip(product_performance['Product Name'], product_performance['SKU'])],
    value=product_performance.iloc[0]['SKU'],
    searchable=True
)

# Dropdown-Menü für Jahr
year_dropdown = dcc.Dropdown(
    id='year-dropdown',
    options=[{'label': year, 'value': year} for year in years],
    value=max(years),
    searchable=False
)

# Dropdown-Menü-Optionen für Jahre
current_year = pd.Timestamp.now().year
years = list(range(2020, current_year + 1))  # Annahme: Daten sind von 2000 bis zum aktuellen Jahr verfügbar
year_options = [{"label": str(year), "value": year} for year in years]

# Dash-Layout definieren
app.layout = html.Div(
    style={'margin-top': '70px'},
    children=[
        html.Div(
            style={'text-align': 'center'},
            children=[
                html.H3('Pizza Dashboard', style={'font-family': 'Arial', 'color': 'slategray'}),
                html.Hr(),
                html.Div('Overview', style={'font-size': '24px', 'font-weight': 'bold'}),
                html.Div(
                    style={'display': 'flex', 'justify-content': 'space-around'},
                    children=[
                        html.Div(
                            style={'border': '1px solid #ccc', 'padding': '20px', 'border-radius': '10px', 'width': '30%', 'text-align': 'center'},
                            children=[
                                html.Div('Total Pizzas Sold', style={'font-size': '16px', 'color': 'dimmed'}),
                                html.Div(id='total_pizzas', style={'font-size': '32px', 'font-weight': 'bold'})
                            ]
                        ),
                        html.Div(
                            style={'border': '1px solid #ccc', 'padding': '20px', 'border-radius': '10px', 'width': '30%', 'text-align': 'center'},
                            children=[
                                html.Div('Total Revenue', style={'font-size': '16px', 'color': 'dimmed'}),
                                html.Div(id='total_revenue', style={'font-size': '32px', 'font-weight': 'bold'})
                            ]
                        )
                    ]
                ),
                html.Hr(),
                html.Div('Details', style={'font-size': '24px', 'font-weight': 'bold'}),
                html.Div(
                    style={'display': 'flex', 'justify-content': 'space-around'},
                    children=[
                        html.Div(
                            style={'border': '1px solid #ccc', 'padding': '20px', 'border-radius': '10px', 'width': '45%'},
                            children=[
                                html.Div('Pizza Sales by Type', style={'font-size': '18px', 'font-weight': 'bold', 'text-align': 'center', 'color': 'grey'}),
                                dcc.Graph(id='pizza_sales_by_type')
                            ]
                        ),
                        html.Div(
                            style={'border': '1px solid #ccc', 'padding': '20px', 'border-radius': '10px', 'width': '45%'},
                            children=[
                                html.Div('Revenue by Type', style={'font-size': '18px', 'font-weight': 'bold', 'text-align': 'center', 'color': 'grey'}),
                                dcc.Graph(id='revenue_by_type')
                            ]
                        )
                    ]
                ),
                html.Div(
                    style={'border': '1px solid #ccc', 'padding': '20px', 'border-radius': '10px', 'margin-top': '20px'},
                    children=[
                        html.Div('Sales Over Time', style={'font-size': '18px', 'font-weight': 'bold', 'text-align': 'center', 'color': 'grey'}),
                        dcc.Graph(id='sales_over_time')
                    ]
                ),
                html.Div(
                    style={'margin-top': '20px'},
                    children=[
                        html.Div('Select Product', style={'font-size': '18px', 'font-weight': 'bold', 'text-align': 'center', 'color': 'grey'}),
                        dcc.Dropdown(id='product-dropdown', options=product_options, placeholder="Wählen Sie ein Produkt"),
                    ]
                ),
                html.Div(
                    style={'margin-top': '20px'},
                    children=[
                        html.Div('Select Year', style={'font-size': '18px', 'font-weight': 'bold', 'text-align': 'center', 'color': 'grey'}),
                        dcc.Dropdown(id='year-dropdown', options=year_options, placeholder="Wählen Sie ein Jahr"),
                    ]
                ),
            ]
        )
    ]
)

@app.callback(
    [Output('total_pizzas', 'children'),
     Output('total_revenue', 'children'),
     Output('pizza_sales_by_type', 'figure'),
     Output('revenue_by_type', 'figure'),
     Output('sales_over_time', 'figure')],
    [Input('product-dropdown', 'value'),
     Input('year-dropdown', 'value')]
)
def update_dashboard(selected_sku, selected_year):
    if selected_sku is None or selected_year is None:
        return "Bitte wählen Sie ein Produkt und ein Jahr", "", px.pie(), px.bar(), px.line()

        # Verkaufsdaten abrufen
    sales_data = get_sales_data(cursor, selected_sku, selected_year)
    total_pizzas = sales_data['Sales Count'].sum()
    total_revenue = sales_data['Sales Count'].sum() * 10  # Annahme: jede Pizza kostet 10 Euro

    # Produktname für die Empfehlungen abrufen
    product_name = products[products["SKU"] == selected_sku]["Product Name"].values[0]

    # Empfehlungen abrufen

    # Diagramme erstellen
    pizza_sales_by_type = px.pie(
        sales_data,
        names='Month',
        values='Sales Count',
        hole=0.5,
        color_discrete_sequence=px.colors.sequential.RdBu
    )

    revenue_by_type = px.bar(
        sales_data,
        x='Month',
        y='Sales Count',
        color='Month',
        color_discrete_sequence=px.colors.sequential.RdBu
    )

    sales_over_time = px.line(
        sales_data,
        x='Month',
        y='Sales Count',
        line_shape='spline',
        render_mode='svg'
    )

    return f"{total_pizzas:,}", f"${total_revenue:,.2f}", pizza_sales_by_type, revenue_by_type, sales_over_time


# Dash-App ausführen
if __name__ == '__main__':
    app.run_server(debug=True)

    # Verbindung schließen
cursor.close()
connection.close()
