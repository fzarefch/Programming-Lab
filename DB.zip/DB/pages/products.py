import dash
from dash import html, dcc, callback, Input, Output
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd
import psycopg2 as pg

dash.register_page(__name__, name='Products', path='/products')

# Verbindungsparameter
db_host = "localhost"
db_name = "postgres"
db_user = "postgres"
db_password = "password"
db_port = "5432"

# Verbindung zur Datenbank herstellen
connection = pg.connect(
    host=db_host,
    database=db_name,
    user=db_user,
    password=db_password,
    port=db_port
)

cursor = connection.cursor()

def get_product_performance():
    try:
        sql_query = """
                    SELECT p.name, p.sku, p.launch as launch_date, MAX(o.orderdate) as last_order_date, COUNT(oi.orderid) as sales_count
                    FROM products p
                    LEFT JOIN orderItems oi ON p.sku = oi.sku
                    LEFT JOIN orders o ON oi.orderid = o.orderid
                    GROUP BY p.name, p.sku, p.launch
                    ORDER BY sales_count DESC;
                    """
        cursor.execute(sql_query)
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Product Name", "SKU", "Launch Date", "Last Order Date", "Sales Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Produktperformance: {e}")
        return pd.DataFrame()

product_performance = get_product_performance()

# Dropdown options
years = pd.DatetimeIndex(product_performance['Launch Date']).year.unique()
year_options = [{"label": str(year), "value": year} for year in years]
product_options = [{'label': name, 'value': sku} for name, sku in zip(product_performance['Product Name'], product_performance['SKU'])]

def get_sales_data(selected_sku, selected_year):
    try:
        sql_query = """
                    SELECT EXTRACT(MONTH FROM o.orderdate) as Month, COUNT(oi.orderid) as Sales_Count
                    FROM orders o
                    LEFT JOIN orderItems oi ON o.orderid = oi.orderid
                    WHERE oi.sku = %s AND EXTRACT(YEAR FROM o.orderdate) = %s
                    GROUP BY EXTRACT(MONTH FROM o.orderdate)
                    ORDER BY EXTRACT(MONTH FROM o.orderdate);
                    """
        cursor.execute(sql_query, (selected_sku, selected_year))
        results = cursor.fetchall()
        return pd.DataFrame(results, columns=["Month", "Sales_Count"])
    except Exception as e:
        print(f"Fehler beim Abrufen der Verkaufsdaten: {e}")
        return pd.DataFrame()

layout = dbc.Container([
    dbc.Row([
        dbc.Col([html.H3('Product Performance')], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Dropdown(id='product-dropdown', options=product_options, placeholder="Wählen Sie ein Produkt")
        ], width=6),
        dbc.Col([
            dcc.Dropdown(id='year-dropdown', options=year_options, placeholder="Wählen Sie ein Jahr")
        ], width=6)
    ]),
    dbc.Row([
        dbc.Col([html.Div(id='total_pizzas')], width=6),
        dbc.Col([html.Div(id='total_revenue')], width=6)
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='pizza_sales_by_type')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='revenue_by_type')
        ], width=12),
    ]),
    dbc.Row([
        dbc.Col([
            dcc.Graph(id='sales_over_time')
        ], width=12),
    ]),
])

@callback(
    [Output('total_pizzas', 'children'),
     Output('total_revenue', 'children'),
     Output('pizza_sales_by_type', 'figure'),
     Output('revenue_by_type', 'figure'),
     Output('sales_over_time', 'figure')],
    [Input('product-dropdown', 'value'),
     Input('year-dropdown', 'value')]
)
def update_dashboard(selected_sku, selected_year):
    if selected_sku is None or selected_year is None:
        return "Bitte wählen Sie ein Produkt und ein Jahr", "", {}, {}, {}

    sales_data = get_sales_data(selected_sku, selected_year)
    total_pizzas = sales_data['Sales_Count'].sum()
    total_revenue = total_pizzas * 10  # Annahme: jede Pizza kostet 10 Euro

    pizza_sales_by_type = px.pie(
        sales_data,
        names='Month',
        values='Sales_Count',
        hole=0.5,
        color_discrete_sequence=px.colors.sequential.RdBu
    )

    revenue_by_type = px.bar(
        sales_data,
        x='Month',
        y='Sales_Count',
        color='Month',
        color_discrete_sequence=px.colors.sequential.RdBu
    )

    sales_over_time = px.line(
        sales_data,
        x='Month',
        y='Sales_Count',
        line_shape='spline',
        render_mode='svg'
    )

    return f"{total_pizzas:,}", f"${total_revenue:,.2f}", pizza_sales_by_type, revenue_by_type, sales_over_time
