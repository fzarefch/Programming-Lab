import dash
from dash import html, dcc, callback, Input, Output
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import pandas as pd

dash.register_page(__name__, name='Customers', path='/customers')

# Beispiel-Daten
customers_data = pd.DataFrame({
    'Customer': ['Customer A', 'Customer B', 'Customer C'],
    'Purchases': [5, 3, 8]
})

layout = dbc.Container([
    dbc.Row([
        dbc.Col([html.H3('Customer Purchases')], width=12, className='row-titles')
    ]),
    dbc.Row([
        dbc.Col([], width=2),
        dbc.Col([
            dcc.Loading(id='customers-loading', type='circle', children=dcc.Graph(id='fig-customers', className='my-graph'))
        ], width=8),
        dbc.Col([], width=2)
    ], className='row-content')
])

@callback(
    Output('fig-customers', 'figure'),
    Input('fig-customers', 'id')
)
def update_customers_graph(_):
    fig = go.Figure(data=[
        go.Bar(name='Purchases', x=customers_data['Customer'], y=customers_data['Purchases'])
    ])
    fig.update_layout(title='Purchases by Customer', xaxis_title='Customer', yaxis_title='Purchases', height=500)
    return fig
